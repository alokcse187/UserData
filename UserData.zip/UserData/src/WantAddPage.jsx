const WantAddPage = ({ addClick, data }) => {
  return (
    <>
      {data.length == 0 ? (
        <h2>
          <p>Sorry, No data found</p>
        </h2>
      ) : (
        ""
      )}
      <div onClick={addClick}>
        <h3>
          <a href="">Want to Add More Data?</a>
        </h3>
      </div>
    </>
  );
};

export default WantAddPage;
