import Input from "./Input";
import { Button } from "./Button";

const FormPage = ({
  showErrorMasg,
  inputVal,
  addBtnClick,
  closeBtnClick,
  inputChange,
}) => {
  return (
    <div>
      <h3>Enter Your Detail</h3>
      {showErrorMasg ? (
        <div className="error">
          <p>Please Enter Details !</p>
        </div>
      ) : (
        ""
      )}
      <Input
        type="text"
        name="addInput"
        val={inputVal}
        placeHolder="Enter Your Name"
        inputChange={inputChange}
      />
      <Button
        btnStyle="btnAdd"
        name="Add"
        type="button"
        btnClick={addBtnClick}
      />
      <Button
        btnStyle="btnDelete"
        name="Close"
        type="button"
        btnClick={closeBtnClick}
      />
    </div>
  );
};

export default FormPage;
