export const Button = ({ name, type, btnClick, btnStyle }) => {
  return (
    <button className={btnStyle} type={type} name={name} onClick={btnClick}>
      {name}
    </button>
  );
};
