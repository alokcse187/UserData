import { useEffect, useState } from "react";
import FormPage from "./FormPage";
import "./styles.css";
import ListData from "./ListData";
import WantAddPage from "./WantAddPage";

export default function App() {
  const USER_DATA_API = "https://gorest.co.in/public/v2/users";
  const [data, setData] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [showErrorMasg, setShowErrorMasg] = useState(false);
  const [inputValue, setInputValue] = useState("");

  useEffect(() => {
    fetch(USER_DATA_API)
      .then((res) => res.json())
      .then((data) => setData(data));
  }, []);

  const deleteButtonClickHandler = (id) => {
    let newData = data.filter((item) => {
      return id !== item.id;
    });
    setData(newData);
  };

  const addInputChangeHandler = (data) => {
    setShowErrorMasg(false);
    setInputValue(data);
  };

  const addButtonClickHandler = () => {
    let uniqueId = Math.floor(Math.random() * 10000000);
    if (inputValue) {
      setData((data) => [{ name: inputValue, id: uniqueId }, ...data]);
      setInputValue("");
    } else {
      document.querySelector("input").classList.add("errorBorder");
      setShowErrorMasg(true);
    }
  };

  const wantAddClickHandler = (event) => {
    event.preventDefault();
    setShowAdd(true);
  };

  const closeButtonClickHandler = () => {
    setShowAdd(false);
    setShowErrorMasg(false);
  };

  return (
    <div className="App">
      {showAdd ? (
        <FormPage
          showErrorMasg={showErrorMasg}
          inputVal={inputValue}
          addBtnClick={addButtonClickHandler}
          closeBtnClick={closeButtonClickHandler}
          inputChange={addInputChangeHandler}
        />
      ) : (
        <WantAddPage addClick={wantAddClickHandler} data={data} />
      )}
      {data.length > 0 && (
        <ListData data={data} delAction={deleteButtonClickHandler} />
      )}
    </div>
  );
}
