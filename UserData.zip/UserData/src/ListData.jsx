import { Button } from "./Button";
import Card from "./Card";

const ListData = ({ data, delAction }) => {
  const delBtnHandler = (id) => {
    delAction(id);
  };
  return data.map((item) => {
    return (
      <Card id={item.id}>
        <span>
          <p>ID: {item.id}</p>
          <p>Name: {item.name}</p>
        </span>
        <span>
          <Button
            btnStyle="btnDelete"
            name="Remove"
            type="button"
            btnClick={delBtnHandler.bind(this, item.id)}
          />
        </span>
      </Card>
    );
  });
};

export default ListData;
