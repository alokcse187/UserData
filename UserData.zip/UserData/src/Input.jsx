const Input = ({ type, name, val, placeHolder, inputChange }) => {
  const inputChangeHandler = (event) => {
    inputChange(event.target.value);
  };
  return (
    <input
      type={type}
      name={name}
      value={val}
      placeholder={placeHolder}
      onChange={inputChangeHandler}
    />
  );
};

export default Input;