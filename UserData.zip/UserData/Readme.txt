The Project is about to User Data Manipulation.
In this project I created multiples of components and styling to show the user data from dummy API('https://gorest.co.in/public/v2/users').
We can add/delete user data.

There are the following steps to run the project.
1. Dowload the project.
2. Open in any editor like VS Code to view the codebase.
3. Open terminal and run 'npm install' and then 'npm start' commnand.
4. New Browser window will open.
5. On First Page I fetched the data from API.
5. Fetched data with Card List form and 'Want to Add More Data?' link will show.
6. There are remove button with each Card.
7. After click on remove button same data will remove from list and data will rearraged.
8. If we deleted all data from Card list then there will be a message 'Sorry, No data found'.
9. On 'Want to Add More Data?' click a form will open.
10. There will be Input box and two button Add, Close will show in form.
11. On click of Add button the same data will added in Card list with unique ID.
12. On click of Close the form page will close and Card/Msg Page will show.